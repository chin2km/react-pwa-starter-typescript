self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "518f1b036c59f852be9d",
    "url": "/bundle.js"
  },
  {
    "revision": "15c651e3ace852819aab715592a95928",
    "url": "/index.html"
  },
  {
    "revision": "518f1b036c59f852be9d",
    "url": "/main.css"
  }
]);