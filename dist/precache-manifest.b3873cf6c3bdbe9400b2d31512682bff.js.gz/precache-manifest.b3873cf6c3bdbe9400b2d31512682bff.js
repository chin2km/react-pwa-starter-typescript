self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "518f1b036c59f852be9d",
    "url": "/bundle.js"
  },
  {
    "revision": "506c8dd4dbba95761915bbbab683fa34",
    "url": "/index.html"
  },
  {
    "revision": "518f1b036c59f852be9d",
    "url": "/main.css"
  }
]);